from netpyne import specs, sim
import os


# template.hoc replace $1 > 1
#morphology.hoc add load_file("import3d.hoc")
#morphology.hoc replace           nl.input("morphology/dend-C300797C-P4_axon-C200897C-P4_-_Scale_x1.000_y1.025_z1.000_-_Clone_11.asc")
#with           nl.input("L4_PC_cADpyr230_1/morphology/dend-C300797C-P4_axon-C200897C-P4_-_Scale_x1.000_y1.025_z1.000_-_Clone_11.asc")
#in synapses/synapses.hoc replace all new File("synapses/synapses.tsv")
#with new File("L4_PC_cADpyr230_1/synapses/synapses.tsv")

# Network parameters
netParams = specs.NetParams()  # object of class NetParams to store the network parameters

cellRule = netParams.importCellParams(
        label='PYR_HH3D_hoc',
        fileName='L4_PC_cADpyr230_1/template.hoc',
        cellName='cADpyr230_L4_PC_f15e35e578', #'cADpyr230_L4_SP_6fe41ae9cd', #'bAC217_L4_BP_d04c4872bd',
        importSynMechs=True)

netParams.popParams['test1'] = {'cellType': 'PYR_HH3D_hoc', 'numCells': 1}

cellRule = netParams.importCellParams(
        label='STELL_HH3D_hoc',
        fileName='L4_SS_cADpyr230_1/template.hoc',
        cellName='cADpyr230_L4_SS_9e49de205b', #'cADpyr230_L4_SP_6fe41ae9cd', #'bAC217_L4_BP_d04c4872bd',
        importSynMechs=True)

netParams.popParams['test2'] = {'cellType': 'STELL_HH3D_hoc', 'numCells': 1}


# Simulation options
simConfig = specs.SimConfig()

simConfig.duration = 100
simConfig.dt = 0.025
simConfig.verbose = False
simConfig.recordTraces = {'V_soma':{'sec':'soma','loc':0.5,'var':'v'}}
simConfig.recordStep = 0.1
simConfig.filename = 'tut2'

simConfig.analysis['plotTraces'] = {'saveFig': True}
simConfig.analysis['plot2Dnet'] = {'saveFig': True}
simConfig.analysis['plotShape'] = {'saveFig': True} 


# Create network and run simulation
sim.createSimulateAnalyze(netParams = netParams, simConfig = simConfig)
