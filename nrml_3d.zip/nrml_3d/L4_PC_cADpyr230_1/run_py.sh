nrnivmodl ./mechanisms
./run.py "$@"
